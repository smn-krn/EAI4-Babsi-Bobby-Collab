from sense_hat import SenseHat
import sys

sense = SenseHat()

if len(sys.argv) < 2:
    sys.exit(1)

gesture = sys.argv[1]

colors = {
    "A": [0, 255, 0],
    "B": [0, 0, 255],
    "C": [255, 255, 0],
    "-": [255, 0, 0]
}

color = colors.get(gesture, [255, 255, 255])

sense.show_letter(
    gesture,
    text_colour=color
)