#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path
import shutil

# UE7: Added csv and struct for output
import csv          
import struct

import numpy as np
import tensorflow as tf

# UE7: Parser is extended to configure pruning parameters
def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train one MNIST model and export baseline/pruned TFLite variants."
    )
    parser.add_argument(
        "--artifacts-dir",
        default="artifacts",
        help="Directory where .tflite files, metrics and test_digit.bmp are written.",
    )
    parser.add_argument("--epochs", type=int, default=5, help="Baseline training epochs.")
    parser.add_argument(
        "--finetune-epochs",
        type=int,
        default=1,
        help="Short retraining after pruning. Use 0 for pure pruning without retraining.",
    )
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--conv-filters", type=int, default=16)
    parser.add_argument("--dense-units", type=int, default=64)
    parser.add_argument(
        "--synapse-prune-ratio",
        type=float,
        default=0.70,
        help="Fraction of individual weights set to zero by magnitude pruning.",
    )
    parser.add_argument(
        "--neuron-prune-ratio",
        type=float,
        default=0.50,
        help="Fraction of hidden dense neurons removed.",
    )
    parser.add_argument(
        "--channel-prune-ratio",
        type=float,
        default=0.50,
        help="Fraction of convolution output channels removed.",
    )
    parser.add_argument(
        "--test-digit-index",
        type=int,
        default=0,
        help="MNIST test image written to test_digit.bmp for Pi benchmark mode.",
    )
    return parser.parse_args()

# UE7: Loading now training and test data for comparison after pruning
def load_data() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
    x_train = x_train.astype("float32") / 255.0
    x_test = x_test.astype("float32") / 255.0
    x_train = x_train[..., None]
    x_test = x_test[..., None]
    return x_train, y_train, x_test, y_test

# UE7: Added another Dense Layer for subsequent pruning
# We add names for the layers to access them in pruning functions (neurons / channels).
def make_model(conv_filters: int = 16, dense_units: int = 64) -> tf.keras.Model:
    model = tf.keras.Sequential(
        [
            tf.keras.layers.Input(shape=(28, 28, 1), name="image"),
            tf.keras.layers.Conv2D(conv_filters, 3, activation="relu", name="conv"),
            tf.keras.layers.MaxPooling2D(name="pool"),
            tf.keras.layers.Flatten(name="flatten"),
            tf.keras.layers.Dense(dense_units, activation="relu", name="hidden"),
            tf.keras.layers.Dense(10, activation="softmax", name="output"),
        ]
    )
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


# UE7: Create function for unstructured pruning by evaluating individual small-magnitude weights
# Small weights are set to 0, the layer shapes stay identical. If a sparse TFLite kernel is available
# it would even reduce CPU instructions.
def prune_synapses(base_model: tf.keras.Model, prune_ratio: float) -> tf.keras.Model:
    # UE7: We clone the model and modify the local instance
    model = tf.keras.models.clone_model(base_model)
    model.set_weights(base_model.get_weights())
    model.compile(
        optimizer="adam",
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    
    kernels = []
    for layer in model.layers:
        weights = layer.get_weights()
        if len(weights) >= 1:
            kernels.append(np.abs(weights[0]).reshape(-1))

    all_kernel_values = np.concatenate(kernels)
    # UE7: We calculate the percentile to fulfill our set pruning ratio
    threshold = np.percentile(all_kernel_values, prune_ratio * 100.0)

    # UE7: For each layer, we set abs(weights) < threshold to 0.0 
    for layer in model.layers:
        weights = layer.get_weights()
        if len(weights) >= 1:
            kernel = weights[0]
            kernel[np.abs(kernel) <= threshold] = 0.0
            weights[0] = kernel
            layer.set_weights(weights)

    return model

# UE7: Helper functon to define, how many neurons (in hidden layer) to keep
# Prune_ratio in percent will be removed from the layer (0.0 <= prune_ratio <= 0.95)
# At least one neuron will always remain
def keep_count(total: int, prune_ratio: float) -> int:
   ratio = float(np.clip(prune_ratio, 0.0, 0.95))
   return max(1, min(total, int(round(total * (1 - ratio)))))

# UE7: Create function to prune neurons, so hidden Dense units have fewer neurons.
# Our model has less dense-matrix work to do
def prune_neurons(base_model: tf.keras.Model, prune_ratio: float) -> tf.keras.Model:
    # UE7: extract convolution, hidden and output layer from the base model
    conv = base_model.get_layer("conv")
    hidden = base_model.get_layer("hidden")
    output = base_model.get_layer("output")

    # UE7: Remove prune_ratio neurons from (old_units) hidden layer, store in new_units
    hidden_kernel, hidden_bias = hidden.get_weights()
    output_kernel, output_bias = output.get_weights()

    # UE7: Count old and calculate new hidden neurons (after pruning)
    # For hidden, kernel shape is input_size, number_of_hidden_neurons, so we use hidden_kernel.shape[1]
    old_units = hidden_kernel.shape[1]
    new_units = keep_count(old_units, prune_ratio)

    # UE7: Score each hidden neuron by importance, based on incoming hidden weights plus outgoing class weights.
    # Each hidden neuron now gets an importance score assigned (scores[0] importance of neuron 0,...)
    score = np.sum(np.abs(hidden_kernel), axis=0) + np.sum(np.abs(output_kernel), axis=1)

    # UE7: Sort neurons by increasing importance and select from pruned index
    keep = np.sort(np.argsort(score)[-new_units:])

    # UE7: Rebuild the model with reduced size, convolution and output layers are not pruned
    # : keeps all input features. If a neuron is removed, its incoming weights and bias are removed
    model = make_model(conv_filters=conv.filters, dense_units=new_units)
    model.get_layer("conv").set_weights(conv.get_weights())
    model.get_layer("hidden").set_weights([hidden_kernel[:, keep], hidden_bias[keep]])
    model.get_layer("output").set_weights([output_kernel[keep, :], output_bias])

    return model


# UE7: Helper function for channel pruning. In Conv2D Layer, feature maps = channels will be removed
# The next dense layer needs also to be fixed. In our model, Conv2D has 16 channels.
# Calculate, which rows from flattened vector need to be removed.
def rows_for_channels(channels: np.ndarray, old_channels: int, pooled_side: int = 13) -> np.ndarray:
    # After Conv2D(3x3 valid) + MaxPooling2D on 28x28 MNIST, the tensor is
    # 13 x 13 x channels. Keras Flatten uses channels-last order, so channel is
    # the fastest-changing index.
    # y=0, x=0, channel=0
    # y=0, x=0, channel=1
    # y=0, x=0, channel=2
    # ...
    rows: list[int] = []
    for y in range(pooled_side):
        for x in range(pooled_side):
            for channel in channels:
                # Convert 3D-index (y, x, channel) into 1D index flattened vector index
                rows.append((y * pooled_side + x) * old_channels + int(channel))

    return np.array(rows, dtype=np.int64)

# UE7: Function to prune individual channels and adapt the following dense layer.
# This changes the model architecture.

def prune_channels(base_model: tf.keras.Model, prune_ratio: float) -> tf.keras.Model:
    # UE7: extract convolution, hidden and output layer from the base model
    conv = base_model.get_layer("conv")
    hidden = base_model.get_layer("hidden")
    output = base_model.get_layer("output")

    # UE7: We load the layer weights of conv
    conv_kernel, conv_bias = conv.get_weights()
    hidden_kernel, hidden_bias = hidden.get_weights()

    # UE7: We count old and new convolution channels
    # For Conv2D, kernel shape is kernel_height x kernel_width x input_channels x output_channels
    # We therefore use conv_kernel.shape[3] -> output_channel 
    old_channels = conv_kernel.shape[3]
    new_channels = keep_count(old_channels, prune_ratio)

    # UE7: Each output channel gets an importance score, based on each convolution weight (except output channel, axis 3)
    # This tells us how large the weighs are for one Conv2D filter - A bigger score means the channel is "more important"
    score = np.sum(np.abs(conv_kernel), axis=(0, 1, 2))

    # UE7: Keep only the strongest channes after sorting by importance score
    keep = np.sort(np.argsort(score)[-new_channels:])

    # UE7: We create the new model with fewer filters, while dense units remain the same
    model = make_model(conv_filters=new_channels, dense_units=hidden_kernel.shape[1])

    # UE7: We only copy the selected channels
    model.get_layer("conv").set_weights([conv_kernel[:, :, :, keep], conv_bias[keep]])

    # UE7: we need to find the corresponding (dense) input rows from the original hidden_kernel
    selected_rows = rows_for_channels(keep, old_channels)

    # UE7: We now copy the adapted hidden dense weights to the new model. The output remains the same
    model.get_layer("hidden").set_weights([hidden_kernel[selected_rows, :], hidden_bias])
    model.get_layer("output").set_weights(output.get_weights())

    return model

# UE7: Implement finetune 
def finetune(model: tf.keras.Model, x: np.ndarray, y: np.ndarray, epochs: int, batch_size: int) -> None:
    if epochs <= 0:
        return
    model.fit(x, y, epochs=epochs, batch_size=batch_size, verbose=2, shuffle=True)

# UE7: Encapsulated export with save / from_saved_model
def export_tflite(model: tf.keras.Model, artifacts_dir: Path, name: str) -> Path:
    # UE7: Artifacts will have lots of files, so model, keras etc. will be separated from now on
    keras_dir = artifacts_dir / "keras"
    saved_model_dir = artifacts_dir / "saved_models" / name
    keras_dir.mkdir(parents=True, exist_ok=True)
    saved_model_dir.parent.mkdir(parents=True, exist_ok=True)

    keras_path = keras_dir / f"{name}.keras"
    tflite_path = artifacts_dir / f"{name}.tflite"

    # UE7: Clear if existing
    if saved_model_dir.exists():
        shutil.rmtree(saved_model_dir)

    model.save(str(keras_path))
    model.export(str(saved_model_dir))

    converter = tf.lite.TFLiteConverter.from_saved_model(str(saved_model_dir))
    tflite_path.write_bytes(converter.convert())
    return tflite_path

# UE7: Helper function to evaluate sparsity
def count_nonzero_weights(model: tf.keras.Model) -> tuple[int, int]:
    total = 0
    nonzero = 0
    for weight in model.get_weights():
        total += int(weight.size)
        nonzero += int(np.count_nonzero(weight))
    return total, nonzero

# UE7: Writes a simple uncompressed 24-bit BMP. The image is scaled up to 280x280 so it is also easy to inspect manually.
def save_test_digit_bmp(path: Path, image_28x28: np.ndarray, scale: int = 10) -> None:
    image = np.repeat(np.repeat(image_28x28, scale, axis=0), scale, axis=1)
    pixels = np.clip(image * 255.0, 0, 255).astype(np.uint8)
    height, width = pixels.shape
    row_stride = (width * 3 + 3) & ~3
    pixel_data_size = row_stride * height
    file_size = 14 + 40 + pixel_data_size

    with path.open("wb") as output:
        output.write(b"BM")
        output.write(struct.pack("<IHHI", file_size, 0, 0, 14 + 40))
        output.write(struct.pack("<IiiHHIIiiII", 40, width, height, 1, 24, 0, pixel_data_size, 0, 0, 0, 0))
        padding = b"\x00" * (row_stride - width * 3)
        for y in range(height - 1, -1, -1):
            row = bytearray()
            for value in pixels[y]:
                row.extend([int(value), int(value), int(value)])  # BMP order: B, G, R
            output.write(row)
            output.write(padding)

# UE7: Print metrics 
def add_metrics_row(rows: list[dict[str, object]], name: str, model: tf.keras.Model, test_result: list[float], tflite_path: Path, method: str) -> None:
    total, nonzero = count_nonzero_weights(model)
    rows.append(
        {
            "model": name,
            "method": method,
            "tflite_file": tflite_path.name,
            "test_loss": f"{test_result[0]:.6f}",
            "test_accuracy": f"{test_result[1]:.6f}",
            "parameters_total": total,
            "parameters_nonzero": nonzero,
            "parameter_sparsity": f"{1.0 - (nonzero / total):.6f}",
        }
    )

# UE7: Main now tests
def main() -> int:
    args = parse_args()
    tf.keras.utils.set_random_seed(42)
    np.random.seed(42)

    artifacts_dir = Path(args.artifacts_dir)
    artifacts_dir.mkdir(parents=True, exist_ok=True)

    x_train, y_train, x_test, y_test = load_data()

    # UE7: Store additional label and testimage for perf 
    test_index = args.test_digit_index % len(x_test)
    save_test_digit_bmp(artifacts_dir / "test_digit.bmp", x_test[test_index, :, :, 0])
    (artifacts_dir / "test_digit_label.txt").write_text(f"{int(y_test[test_index])}\n", encoding="utf-8")

    rows: list[dict[str, object]] = []

    # UE7: Set epochs and batch size in arguments
    baseline = make_model(args.conv_filters, args.dense_units)
    baseline.fit(
        x_train,
        y_train,
        validation_split=0.2,
        epochs=args.epochs,
        batch_size=args.batch_size,
        verbose=2,
        shuffle=True,
    )

    models: list[tuple[str, str, tf.keras.Model]] = [("baseline", "normal training", baseline)]

    # UE7: Apply synapse pruning
    synapse = prune_synapses(baseline, args.synapse_prune_ratio)
    finetune(synapse, x_train, y_train, args.finetune_epochs, args.batch_size)
    # Reapply unstructured pruning after fine-tuning so the zeroed synapses remain zero.
    synapse = prune_synapses(synapse, args.synapse_prune_ratio)
    models.append(("synapse_pruned", "unstructured small-weight pruning", synapse))

    # UE7: Apply neuron pruning
    neuron = prune_neurons(baseline, args.neuron_prune_ratio)
    finetune(neuron, x_train, y_train, args.finetune_epochs, args.batch_size)
    models.append(("neuron_pruned", "structured hidden-neuron pruning", neuron))

    # UE7: Apply channel pruning
    channel = prune_channels(baseline, args.channel_prune_ratio)
    finetune(channel, x_train, y_train, args.finetune_epochs, args.batch_size)
    models.append(("channel_pruned", "structured convolution-channel pruning", channel))

    # UE7: Evaluate and export each and every model
    for name, method, model in models:
        test_result = model.evaluate(x_test, y_test, verbose=0)
        tflite_path = export_tflite(model, artifacts_dir, name)
        add_metrics_row(rows, name, model, test_result, tflite_path, method)
        print(f"Exported {tflite_path} accuracy={test_result[1]:.4f}")

    # Keep the old file name for the existing deploy/debug workflow.
    shutil.copy2(artifacts_dir / "baseline.tflite", artifacts_dir / "model.tflite")

    metrics_path = artifacts_dir / "model_metrics.csv"
    with metrics_path.open("w", newline="", encoding="utf-8") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"Saved benchmark BMP: {artifacts_dir / 'test_digit.bmp'}")
    print(f"Saved test digit label: {int(y_test[test_index])}")
    print(f"Saved model metrics: {metrics_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
