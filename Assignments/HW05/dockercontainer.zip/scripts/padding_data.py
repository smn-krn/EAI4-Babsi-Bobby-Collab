#!/usr/bin/env python3

from pathlib import Path
import pandas as pd
import numpy as np

WINDOW_SIZE = 150 # the fixed number of rows we want for each recording, which matches the sequence length used during training

# Our CSV format
HEADINGS = [
    "timestamp_ms",
    "accel_x",
    "accel_y",
    "accel_z",
    "gyro_x",
    "gyro_y",
    "gyro_z",
    "mag_x",
    "mag_y",
    "mag_z",
]

def pad_file(csv_path: Path, new_path: Path, window_size: int = WINDOW_SIZE):
    """
    Pad a CSV file with zeros to ensure it has a fixed number of rows (window_size).
    """

    df = pd.read_csv(csv_path)

    n_rows = len(df)

    # Skip already-large files
    if n_rows >= window_size:
        return False

    print(
        f"Padding {csv_path.name}: "
        f"{n_rows} -> {window_size}"
    )

    # zero padding

    rows_to_add = window_size - n_rows

    padding = pd.DataFrame(
        np.zeros((rows_to_add, len(df.columns))),
        columns=df.columns
    )
    # Concatenate the original DataFrame with the padding DataFrame

    padded_df = pd.concat(
        [df, padding],
        ignore_index=True
    )

    # Write to a new folder called recordings_padded
    padded_df.to_csv(new_path, index=False)

    return True


def main():

    recordings_dir = Path("recordings")
    padded_dir = Path("recordings_padded")
    padded_dir.mkdir(exist_ok=True)

    csv_files = sorted(recordings_dir.glob("*.csv"))

    if not csv_files:
        print("No CSV files found.")
        return

    padded_count = 0

    for csv_path in csv_files:

        try:
            new_path = padded_dir / csv_path.name
            changed = pad_file(csv_path, new_path) 
            # call the pad_file function to pad the CSV file and write it to the new path, 
            # which returns True if the file was padded and False if it was already large enough

            if changed:
                padded_count += 1

        except Exception as exc:

            print(
                f"Failed processing {csv_path.name}: {exc}"
            )

    print()

    print(f"Finished. Padded {padded_count} file(s).")


if __name__ == "__main__":
    main()