// main.cpp

#include <chrono>
#include <exception>
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <map>
#include <cmath>
#include "RTIMULib.h"
#include <thread>

#include "TfliteGestureClassifier.h"
#include <fstream>
#include <sstream>

namespace {

const std::vector<std::string> kClassNames = {
    "-",
    "A",
    "B",
    "C"
}; // Class 0 is "no gesture", so the actual gestures start from index 1.

constexpr const char* kModelPath = "baseline.tflite"; // Default model path. Can be overridden with --model.
constexpr const char* kCsvPath = "0001.csv"; // Default CSV file for testing. Can be overridden with --csv.

constexpr int kDefaultWarmupRuns = 20; // Number of warmup runs before benchmarking. Can be overridden with --warmup.
constexpr int kDefaultBenchmarkRuns = 1000; // Number of runs to perform for benchmarking. Can be overridden with --runs.

// Selects which use case should run.
enum class ProgramMode {
  kGestureInference,
  kBenchmark,
};

// Stores command line options.
struct ProgramOptions {
  std::string model_path = kModelPath; // Default model path.
  std::string csv_path = kCsvPath; // Default CSV path for testing.4
  ProgramMode mode = ProgramMode::kGestureInference; // Default to gesture inference mode.
  int warmup_runs = kDefaultWarmupRuns;
  int benchmark_runs = kDefaultBenchmarkRuns;
  bool stream_mode = false; // Whether to run in streaming mode
};

// Prints the command line usage.
void PrintUsage(const char* program_name) {
  std::cerr
      << "Usage:\n"
      << "  "
      << program_name
      << " --model baseline.tflite --csv test_gesture.csv\n";
}

// Parses a positive integer option value. Verifies that the value is positive.
bool ParsePositiveInt(const std::string& text, int* value) {
  try {
    const int parsed = std::stoi(text); // stoi throws if the string is not a valid integer.

    if (parsed <= 0) {
      return false;
    }

    *value = parsed; // Store the parsed value in the output parameter.
    return true;
  } catch (const std::exception&) { // Catch any exception from stoi (invalid argument, out of range, etc.)
    return false;
  }
}

// Parses all command line arguments.
bool ParseArgs(int argc, char** argv, ProgramOptions* options) {
  for (int index = 1; index < argc; ++index) {
    const std::string arg = argv[index];

    if (arg == "--help" || arg == "-h") {
      PrintUsage(argv[0]);
      return false;
    }

    if (arg == "--model" && index + 1 < argc) {
      options->model_path = argv[++index];
      continue;
    }

    if (arg == "--csv" && index + 1 < argc) {
      options->csv_path = argv[++index];
      continue;
    }

    if (arg == "--runs" && index + 1 < argc) {
      if (!ParsePositiveInt(argv[++index], &options->benchmark_runs)) {
        std::cerr << "Invalid --runs value.\n";
        return false;
      }

      continue;
    }

    if (arg == "--warmup" && index + 1 < argc) {
      if (!ParsePositiveInt(argv[++index], &options->warmup_runs)) {
        std::cerr << "Invalid --warmup value.\n";
        return false;
      }

      continue;
    }

    // Keep the old workflow: ./program model.tflite
    if (!arg.empty() && arg[0] != '-') {
      // If the argument doesn't start with a dash, treat it as a model path (legacy behavior).
      options->model_path = arg;
      continue;
    }

    if (arg == "--benchmark") {
      // If the --benchmark flag is present, set the mode to benchmark. This will cause the program to run in benchmark mode instead of gesture inference mode.
        options->mode = ProgramMode::kBenchmark;
        continue;
    }

    else if (arg == "--stream") {
      options->stream_mode = true;
      continue;
  }

    std::cerr << "Unknown or incomplete argument: " << arg << "\n";
    PrintUsage(argv[0]);
    return false;
  }

  return true;
}

void NormalizeFeatures(
    std::vector<float>* data_input,
    int features_per_row = 9)
{
    const int rows =
        static_cast<int>(data_input->size())
        / features_per_row;

    for (int feature = 0;
         feature < features_per_row;
         ++feature)
    {
        float mean = 0.0f;

        for (int row = 0; row < rows; ++row)
        {
            mean += (*data_input)[
                row * features_per_row + feature
            ];
        }

        mean /= static_cast<float>(rows);

        float variance = 0.0f;

        for (int row = 0; row < rows; ++row)
        {
            const float value =
                (*data_input)[
                    row * features_per_row + feature
                ];

            const float diff =
                value - mean;

            variance += diff * diff;
        }

        variance /= static_cast<float>(rows);

        float stddev =
            std::sqrt(variance);

        if (stddev < 1e-6f)
        {
            stddev = 1.0f;
        }

        for (int row = 0; row < rows; ++row)
        {
            float& value =
                (*data_input)[
                    row * features_per_row + feature
                ];

            value =
                (value - mean) / stddev;
        }
    }
}

// Loads and preprocesses the CSV.
bool LoadCsv(const std::string& path, std::vector<float>* data_input) {

  std::ifstream file(path);

  if (!file.is_open()) {
    std::cerr << "Failed to open CSV file.\n";
    return false;
  }

  std::string line;

  // Skip header
  std::getline(file, line);

  constexpr int kExpectedRows = 150; // Expected number of rows in the input CSV. Shorter recordings will be zero-padded, and longer recordings will be cropped.
  constexpr int kFeaturesPerRow = 9; // Expected number of features per row (excluding timestamp). This should match the model's expected input shape.

  int row_count = 0;

  while (std::getline(file, line)) {

    std::stringstream ss(line);
    std::string cell;

    int column = 0;

    // ------------------------------------------------------------------------
    // Crop extra rows
    // ------------------------------------------------------------------------

    if (row_count >= kExpectedRows) {

      std::cerr
          << "WARNING: CSV has more than "
          << kExpectedRows
          << " rows. Extra rows were cropped.\n";

      break; // due to breaking here, only the first kExpectedRows will be processed, and the rest will be ignored.
    }

    while (std::getline(ss, cell, ',')) {

      // Skip timestamp
      if (column > 0) {

        float value = std::stof(cell); // Convert the cell value to float. This assumes that the CSV values are valid floats

        data_input->push_back(value); // Store the value in the data_input vector, which will be used for inference.
      }

      column++;
    }

    row_count++;
  }

  // --------------------------------------------------------------------------
  // Pad short recordings
  // --------------------------------------------------------------------------

  if (row_count < kExpectedRows) {

    std::cerr
        << "WARNING: CSV has only "
        << row_count
        << " rows. Zero-padding to "
        << kExpectedRows
        << ".\n";

    const int missing_rows =
        kExpectedRows - row_count; // Calculate how many rows are missing to reach the expected number of rows.

    const int missing_values =
        missing_rows * kFeaturesPerRow; // Calculate how many values are missing based on the number of missing rows and features per row.

    data_input->resize(
        data_input->size() + missing_values,
        0.0f // Pad the missing values with zeros. This will ensure that the input data has the correct shape for the model, even if the original CSV had fewer rows than expected.
    );
  }
  // --------------------------------------------------------------------------
  // Per-feature normalization
  // --------------------------------------------------------------------------
  
  NormalizeFeatures(data_input);

  return true;
  }

// --------------------------------------------------------------------------
// Added benchmark function for EX 05
// --------------------------------------------------------------------------
int RunBenchmark(
    const ProgramOptions& options,
    TfliteGestureClassifier* classifier) {

  std::vector<float> data_input;

  if (!LoadCsv(options.csv_path, &data_input)) {
    return 1;
  }

  constexpr int kExpectedValues = 150 * 9;
  GesturePrediction prediction;

  if (data_input.size() != kExpectedValues) {
    std::cerr
        << "Expected "
        << kExpectedValues
        << " values but got "
        << data_input.size()
        << "\n";
    return 1;
  }

  // warmup
  for (int i = 0; i < options.warmup_runs; ++i) {
    classifier->Predict(data_input);
  }

  // benchmark
  using Clock = std::chrono::steady_clock;

  prediction = classifier->Predict(data_input);

  // Check if the prediction was successful before measuring the time. 
  // If the prediction failed, we should not proceed with benchmarking and instead report the error.
  if (!classifier->ok()) {
      std::cerr << "Inference failed: "
                << classifier->error_message()
                << "\n";
      return 1;
  }

  auto start = Clock::now();

  for (int i = 0; i < options.benchmark_runs; ++i) {
      classifier->Predict(data_input);
  }

  auto end = Clock::now();

  const auto total_us =
      std::chrono::duration_cast<
          std::chrono::microseconds>(
          end - start).count();

  std::cout
      << "Total measured inference time in ms: "
      << static_cast<double>(total_us) / 1000.0
      << " ms\n";

  const double avg_us =
      static_cast<double>(total_us)
      / options.benchmark_runs;

  std::cout
      << "Average inference time in ms: "
      << avg_us / 1000.0
      << " ms\n";

  std::cout << "Model: "
            << options.model_path << "\n";

  std::cout << "CSV: "
            << options.csv_path << "\n";

  std::cout << "\nFINAL PREDICTION\n";

  std::cout << "Predicted gesture class: "
            << kClassNames[prediction.predicted_class]
            << " ("
            << prediction.predicted_class
            << ")\n";

  std::cout << "Confidence: "
            << std::fixed
            << std::setprecision(6)
            << prediction.confidence
            << "\n";

  std::cout << "Runs: "
            << options.benchmark_runs
            << "\n";

  return 0;
}

// --------------------------------------------------------------------------
// RunGestureInference
// --------------------------------------------------------------------------
int RunGestureInference(const ProgramOptions& options,
                        TfliteGestureClassifier* classifier) {

  std::vector<float> data_input;

  if (!LoadCsv(options.csv_path, &data_input)) {
    return 1;
  }

  // --------------------------------------------------------------------------
  // Expected input shape
  // --------------------------------------------------------------------------

  constexpr int kExpectedRows = 150;
  constexpr int kFeaturesPerRow = 9;

  constexpr int kExpectedValues =
      kExpectedRows * kFeaturesPerRow;

  // --------------------------------------------------------------------------
  // Validate input size (double check that the CSV loading and preprocessing produced the expected number of values for inference)
  // --------------------------------------------------------------------------

  if (data_input.size() != kExpectedValues) {

    std::cerr
        << "Expected "
        << kExpectedValues
        << " values but got "
        << data_input.size()
        << "\n";

    return 1;
  }

  // --------------------------------------------------------------------------
  // Run inference
  // --------------------------------------------------------------------------

  GesturePrediction prediction =
      classifier->Predict(data_input); // Run the prediction using the classifier. The input data is passed as a vector of floats, which should match the expected input shape of the model. The output is a GesturePrediction struct that contains the predicted class, confidence, and scores for each class.

  if (!classifier->ok()) {

    std::cerr << "Inference failed: "
              << classifier->error_message()
              << "\n";

    return 1;
  }

    // --------------------------------------------------------------------------
    // Final result
    // --------------------------------------------------------------------------

    std::cout << "\n";

    std::cout << "Model: "
              << options.model_path << "\n";

    std::cout << "CSV: "
              << options.csv_path << "\n";

    std::cout << "\nFINAL PREDICTION\n";

    std::cout << "Predicted gesture class: "
              << kClassNames[prediction.predicted_class]
              << " ("
              << prediction.predicted_class
              << ")\n";

    std::cout << "Confidence: "
              << std::fixed
              << std::setprecision(6)
              << prediction.confidence
              << "\n";

    return 0;
  }

// --------------------------------------------------------------------------
// RunStreamingMode
// --------------------------------------------------------------------------
int RunStreamingMode(
    TfliteGestureClassifier* classifier)
{
    auto settings =
        std::make_unique<RTIMUSettings>("RTIMULib");

    auto imu =
        std::unique_ptr<RTIMU>(
            RTIMU::createIMU(settings.get()));

    if (!imu || imu->IMUType() == RTIMU_TYPE_NULL) {
        std::cerr << "No IMU found\n";
        return 1;
    }

    if (!imu->IMUInit()) {
        std::cerr << "IMU init failed\n";
        return 1;
    }

    imu->setAccelEnable(true);
    imu->setGyroEnable(true);
    imu->setCompassEnable(true);

    constexpr size_t kWindowSize = 150 * 9;

    std::vector<float> window;
    window.reserve(kWindowSize);

    std::cout << "Streaming mode started\n";

    using Clock = std::chrono::steady_clock;

    auto last_inference = Clock::now();

    constexpr auto kInferenceInterval =
        std::chrono::milliseconds(500);

    int previous_prediction = -1;
    int stable_count = 0;
    int pAppearanceThreshold = 4; // Number of consecutive predictions required to confirm a gesture. 
    // This helps to reduce false positives by ensuring that a gesture is consistently recognized over multiple inference runs before it is considered confirmed.

    // bool gesture_confirmed = false;
    bool window_ready_printed = false;

    while (true) {

        while (imu->IMURead()) {

            const auto& data = imu->getIMUData();

            if (!(data.accelValid &&
                  data.gyroValid &&
                  data.compassValid))
            {
                continue;
            }

            window.push_back(data.accel.x());
            window.push_back(data.accel.y());
            window.push_back(data.accel.z());

            window.push_back(data.gyro.x());
            window.push_back(data.gyro.y());
            window.push_back(data.gyro.z());

            window.push_back(data.compass.x());
            window.push_back(data.compass.y());
            window.push_back(data.compass.z());

            const int samples =
              static_cast<int>(window.size() / 9); // Calculate the number of samples based on the total number of values in the window divided by the number of features per sample (9 in this case).

            if (!window_ready_printed)
            {
                std::cout
                    << "\rCollecting samples: "
                    << samples
                    << "/150"
                    << std::flush;
            }

            while (window.size() > kWindowSize) {
                window.erase(
                    window.begin(),
                    window.begin() + 9);
            } // If the window has more than the expected number of values (kWindowSize), we remove the oldest sample (the first 9 values) to maintain a sliding window of the most recent 150 samples.

            if (window.size() == kWindowSize) {

              if (!window_ready_printed)
                  {
                      std::cout
                          << "\nWindow full. Starting live inference.\n";

                      window_ready_printed = true;
                  }

                auto now = Clock::now();

                if (now - last_inference < kInferenceInterval) {
                    continue;
                }

                last_inference = now;

                std::vector<float> normalized = window;

                std::cout
                    << "\rNormalizing + inferencing...      "
                    << std::flush;

                NormalizeFeatures(&normalized);

                GesturePrediction prediction =
                    classifier->Predict(normalized);

                if (prediction.predicted_class ==
                    previous_prediction)
                {
                    stable_count++;
                }
                else
                {
                    previous_prediction =
                        prediction.predicted_class;

                    stable_count = 1;

                    // gesture_confirmed = false;
                }

                if (stable_count >= pAppearanceThreshold && prediction.confidence >= 0.5f)
                {
                    // gesture_confirmed = true;

                    static int last_displayed = -1;

                    if (prediction.predicted_class != last_displayed)
                    {
                        last_displayed = prediction.predicted_class;

                        const std::string cmd =
                            "python3 display_prediction.py " +
                            kClassNames[prediction.predicted_class] +
                            " &";

                        std::system(cmd.c_str());
                    }

                    std::cout
                        << "\nGesture: "
                        << kClassNames[prediction.predicted_class]
                        << " confidence="
                        << std::fixed
                        << std::setprecision(3)
                        << prediction.confidence*100.0f << " %"
                        << "\n"
                        << "Other gesture confidence: "
                        << "A=" << prediction.scores[1]*100.0f << " %"
                        << " B=" << prediction.scores[2]*100.0f << " %"
                        << " C=" << prediction.scores[3]*100.0f << " %"
                        << " -= " << prediction.scores[0]*100.0f << " %"
                        << "\n"
                        << std::endl;

                }
                else
                {
                    std::cout
                        << "\rNo stable gesture yet ("
                        << stable_count
                        << "/" << pAppearanceThreshold << ")                    "
                        << std::flush;
                }
            }
        }

        std::this_thread::sleep_for(
            std::chrono::milliseconds(20));
    }

    return 0;
}

} // namespace

int main(int argc, char** argv) {
  ProgramOptions options;

  // Parse command line options.
  if (!ParseArgs(argc, argv, &options)) {
    return 1;
  }

  TfliteGestureClassifier classifier(options.model_path);

  if (!classifier.ok()) {
    std::cerr << "Failed to load model: "
              << classifier.error_message() << "\n";
    return 1;
  }

  if (options.stream_mode) {
    return RunStreamingMode(&classifier);
  }

  // Run the selected program mode (gesture inference or benchmark).
  switch (options.mode) {
    case ProgramMode::kGestureInference:
        return RunGestureInference(
            options,
            &classifier);

    case ProgramMode::kBenchmark:
        return RunBenchmark(
            options,
            &classifier);
    }

    return 1;

}