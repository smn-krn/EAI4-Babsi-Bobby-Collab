#pragma once

#include <memory>
#include <string>
#include <vector>

//Added for HW
struct GesturePrediction
{
    int predicted_class;
    float confidence;
    std::vector<float> scores;
};


class TfliteGestureClassifier {
 public:
  explicit TfliteGestureClassifier(const std::string& model_path);
  ~TfliteGestureClassifier();

  TfliteGestureClassifier(const TfliteGestureClassifier&) = delete;
  TfliteGestureClassifier& operator=(const TfliteGestureClassifier&) = delete;
  TfliteGestureClassifier(TfliteGestureClassifier&&) = delete;
  TfliteGestureClassifier& operator=(TfliteGestureClassifier&&) = delete;

  bool ok() const { return ok_; }
  const std::string& error_message() const { return error_message_; }
  GesturePrediction Predict(
    const std::vector<float>& input_data);

 private:
  struct Impl;

  bool Load(const std::string& model_path);
  bool CopyInput(const std::vector<float>& input_data);
  std::vector<float> ReadOutput() const;

  std::unique_ptr<Impl> impl_;
  bool ok_ = false;
  std::string error_message_;
};
