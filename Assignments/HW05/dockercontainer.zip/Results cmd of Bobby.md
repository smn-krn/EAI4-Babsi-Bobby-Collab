cmd to execute streaming mode on pi: 
```bash
./pi_demo --model baseline.tflite --stream
```

# Training accuracy
![alt text](image.png)

```bash
 *  Executing task: make train 

[sync] REMOTE_DATA not set, skipping sync
".venv/bin/python" scripts/train_and_convert.py \
        --artifacts-dir "artifacts" \
        --data-dir "recordings" \

2026-06-02 23:29:13.819593: I tensorflow/core/util/port.cc:113] oneDNN custom operations are on. You may see slightly different numerical results due to floating-point round-off errors from different computation orders. To turn them off, set the environment variable `TF_ENABLE_ONEDNN_OPTS=0`.
2026-06-02 23:29:13.853551: I external/local_tsl/tsl/cuda/cudart_stub.cc:32] Could not find cuda drivers on your machine, GPU will not be used.
2026-06-02 23:29:15.421800: I external/local_tsl/tsl/cuda/cudart_stub.cc:32] Could not find cuda drivers on your machine, GPU will not be used.
2026-06-02 23:29:21.097164: I tensorflow/core/platform/cpu_feature_guard.cc:210] This TensorFlow binary is optimized to use available CPU instructions in performance-critical operations.
To enable the following instructions: AVX2 AVX_VNNI FMA, in other operations, rebuild TensorFlow with the appropriate compiler flags.
2026-06-02 23:29:37.240305: W tensorflow/compiler/tf2tensorrt/utils/py_utils.cc:38] TF-TRT Warning: Could not find TensorRT
--- Loading data ---
Sample label_map keys: ['0001', '0002', '0003', '0004', '0005']
Example file_id: 0001
Total recordings: 281  shape per sample: (150, 9)

Class mapping:
0 -> -
1 -> A
2 -> B
3 -> C

Files per class:
-: 76 files
A: 70 files
B: 70 files
C: 71 files

--- Splitting ---
Split: train=196 val=42 test=43

--- Model ---
Model: "gesture_1d_cnn"
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━┓
┃ Layer (type)                         ┃ Output Shape                ┃         Param # ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━┩
│ conv1 (Conv1D)                       │ (None, 150, 32)             │             896 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ pool1 (MaxPooling1D)                 │ (None, 75, 32)              │               0 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv2 (Conv1D)                       │ (None, 75, 64)              │           6,208 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ pool2 (MaxPooling1D)                 │ (None, 37, 64)              │               0 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ conv3 (Conv1D)                       │ (None, 37, 64)              │          12,352 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ gap (GlobalAveragePooling1D)         │ (None, 64)                  │               0 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dense1 (Dense)                       │ (None, 64)                  │           4,160 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ dropout (Dropout)                    │ (None, 64)                  │               0 │
├──────────────────────────────────────┼─────────────────────────────┼─────────────────┤
│ output (Dense)                       │ (None, 4)                   │             260 │
└──────────────────────────────────────┴─────────────────────────────┴─────────────────┘
 Total params: 23,876 (93.27 KB)
 Trainable params: 23,876 (93.27 KB)
 Non-trainable params: 0 (0.00 B)

--- Training ---
Epoch 1/60
49/49 - 3s - 62ms/step - accuracy: 0.3916 - loss: 1.2759 - val_accuracy: 0.5714 - val_loss: 1.0035 - learning_rate: 0.0010
Epoch 2/60
49/49 - 0s - 8ms/step - accuracy: 0.6467 - loss: 0.8214 - val_accuracy: 0.7857 - val_loss: 0.6519 - learning_rate: 0.0010
Epoch 3/60
49/49 - 0s - 8ms/step - accuracy: 0.7806 - loss: 0.5558 - val_accuracy: 0.9048 - val_loss: 0.4571 - learning_rate: 0.0010
Epoch 4/60
49/49 - 0s - 7ms/step - accuracy: 0.8457 - loss: 0.4335 - val_accuracy: 0.8810 - val_loss: 0.4097 - learning_rate: 0.0010
Epoch 5/60
49/49 - 0s - 7ms/step - accuracy: 0.8878 - loss: 0.3220 - val_accuracy: 0.8571 - val_loss: 0.3416 - learning_rate: 0.0010
Epoch 6/60
49/49 - 0s - 7ms/step - accuracy: 0.9094 - loss: 0.2605 - val_accuracy: 0.8810 - val_loss: 0.3595 - learning_rate: 0.0010
Epoch 7/60
49/49 - 0s - 7ms/step - accuracy: 0.9222 - loss: 0.2622 - val_accuracy: 0.8571 - val_loss: 0.3460 - learning_rate: 0.0010
Epoch 8/60
49/49 - 0s - 7ms/step - accuracy: 0.9605 - loss: 0.1488 - val_accuracy: 0.8571 - val_loss: 0.3581 - learning_rate: 0.0010
Epoch 9/60
49/49 - 0s - 7ms/step - accuracy: 0.9605 - loss: 0.1412 - val_accuracy: 0.9286 - val_loss: 0.2532 - learning_rate: 0.0010
Epoch 10/60
49/49 - 0s - 7ms/step - accuracy: 0.9643 - loss: 0.1221 - val_accuracy: 0.8571 - val_loss: 0.3202 - learning_rate: 0.0010
Epoch 11/60
49/49 - 0s - 7ms/step - accuracy: 0.9592 - loss: 0.1323 - val_accuracy: 0.8571 - val_loss: 0.3110 - learning_rate: 0.0010
Epoch 12/60
49/49 - 0s - 8ms/step - accuracy: 0.9694 - loss: 0.0901 - val_accuracy: 0.9286 - val_loss: 0.2307 - learning_rate: 0.0010
Epoch 13/60
49/49 - 0s - 7ms/step - accuracy: 0.9834 - loss: 0.0623 - val_accuracy: 0.9048 - val_loss: 0.2700 - learning_rate: 0.0010
Epoch 14/60
49/49 - 0s - 7ms/step - accuracy: 0.9847 - loss: 0.0552 - val_accuracy: 0.9286 - val_loss: 0.2220 - learning_rate: 0.0010
Epoch 15/60
49/49 - 0s - 7ms/step - accuracy: 0.9936 - loss: 0.0312 - val_accuracy: 0.9048 - val_loss: 0.2814 - learning_rate: 0.0010
Epoch 16/60
49/49 - 0s - 8ms/step - accuracy: 0.9936 - loss: 0.0398 - val_accuracy: 0.9286 - val_loss: 0.2881 - learning_rate: 0.0010
Epoch 17/60
49/49 - 0s - 8ms/step - accuracy: 0.9962 - loss: 0.0242 - val_accuracy: 0.9048 - val_loss: 0.2695 - learning_rate: 0.0010
Epoch 18/60
49/49 - 0s - 9ms/step - accuracy: 0.9707 - loss: 0.0727 - val_accuracy: 0.7857 - val_loss: 0.6009 - learning_rate: 0.0010
Epoch 19/60
49/49 - 0s - 7ms/step - accuracy: 0.9732 - loss: 0.0715 - val_accuracy: 0.9048 - val_loss: 0.2709 - learning_rate: 0.0010
Epoch 20/60
49/49 - 0s - 8ms/step - accuracy: 0.9987 - loss: 0.0207 - val_accuracy: 0.9286 - val_loss: 0.1987 - learning_rate: 0.0010
Epoch 21/60
49/49 - 0s - 8ms/step - accuracy: 1.0000 - loss: 0.0131 - val_accuracy: 0.9524 - val_loss: 0.2045 - learning_rate: 0.0010
Epoch 22/60
49/49 - 0s - 8ms/step - accuracy: 0.9974 - loss: 0.0114 - val_accuracy: 0.9524 - val_loss: 0.2158 - learning_rate: 0.0010
Epoch 23/60
49/49 - 0s - 8ms/step - accuracy: 1.0000 - loss: 0.0087 - val_accuracy: 0.9524 - val_loss: 0.2010 - learning_rate: 0.0010
Epoch 24/60
49/49 - 0s - 9ms/step - accuracy: 0.9987 - loss: 0.0104 - val_accuracy: 0.9286 - val_loss: 0.2118 - learning_rate: 0.0010
Epoch 25/60
49/49 - 0s - 8ms/step - accuracy: 0.9987 - loss: 0.0084 - val_accuracy: 0.9524 - val_loss: 0.1292 - learning_rate: 0.0010
Epoch 26/60
49/49 - 0s - 7ms/step - accuracy: 0.9987 - loss: 0.0108 - val_accuracy: 0.8095 - val_loss: 0.4436 - learning_rate: 0.0010
Epoch 27/60
49/49 - 0s - 8ms/step - accuracy: 0.9872 - loss: 0.0318 - val_accuracy: 0.8810 - val_loss: 0.4000 - learning_rate: 0.0010
Epoch 28/60
49/49 - 0s - 7ms/step - accuracy: 0.9974 - loss: 0.0133 - val_accuracy: 0.9048 - val_loss: 0.2586 - learning_rate: 0.0010
Epoch 29/60
49/49 - 0s - 7ms/step - accuracy: 0.9987 - loss: 0.0082 - val_accuracy: 0.9286 - val_loss: 0.2056 - learning_rate: 0.0010
Epoch 30/60
49/49 - 0s - 8ms/step - accuracy: 1.0000 - loss: 0.0055 - val_accuracy: 0.9524 - val_loss: 0.1709 - learning_rate: 0.0010
Epoch 31/60
49/49 - 0s - 6ms/step - accuracy: 0.9949 - loss: 0.0122 - val_accuracy: 0.9524 - val_loss: 0.1578 - learning_rate: 0.0010
Epoch 32/60

Epoch 32: ReduceLROnPlateau reducing learning rate to 0.0005000000237487257.
49/49 - 0s - 9ms/step - accuracy: 0.9962 - loss: 0.0127 - val_accuracy: 0.9286 - val_loss: 0.2092 - learning_rate: 0.0010
Epoch 33/60
49/49 - 0s - 8ms/step - accuracy: 1.0000 - loss: 0.0046 - val_accuracy: 0.9524 - val_loss: 0.1464 - learning_rate: 5.0000e-04
Epoch 34/60
49/49 - 0s - 7ms/step - accuracy: 0.9987 - loss: 0.0061 - val_accuracy: 0.9524 - val_loss: 0.1675 - learning_rate: 5.0000e-04
Epoch 35/60
49/49 - 0s - 7ms/step - accuracy: 1.0000 - loss: 0.0039 - val_accuracy: 0.9048 - val_loss: 0.2438 - learning_rate: 5.0000e-04
Epoch 36/60
49/49 - 0s - 7ms/step - accuracy: 1.0000 - loss: 0.0025 - val_accuracy: 0.9286 - val_loss: 0.1997 - learning_rate: 5.0000e-04
Epoch 37/60
49/49 - 0s - 7ms/step - accuracy: 0.9987 - loss: 0.0035 - val_accuracy: 0.9048 - val_loss: 0.2457 - learning_rate: 5.0000e-04
Epoch 38/60
49/49 - 0s - 7ms/step - accuracy: 1.0000 - loss: 0.0040 - val_accuracy: 0.9286 - val_loss: 0.1778 - learning_rate: 5.0000e-04
Epoch 39/60

Epoch 39: ReduceLROnPlateau reducing learning rate to 0.0002500000118743628.
49/49 - 0s - 7ms/step - accuracy: 1.0000 - loss: 0.0027 - val_accuracy: 0.9286 - val_loss: 0.1696 - learning_rate: 5.0000e-04
Epoch 40/60
49/49 - 0s - 7ms/step - accuracy: 1.0000 - loss: 0.0040 - val_accuracy: 0.9524 - val_loss: 0.1943 - learning_rate: 2.5000e-04
Epoch 40: early stopping
Restoring model weights from the end of the best epoch: 25.

--- Pruning ---

Channel pruning: 
Conv1 channels: 32
Removing: 4

Combined pruning: 
Conv1 channels: 32
Removing: 4

--- Model Evaluation ---
baseline             | loss=0.3030 | accuracy=93.02%
synapse_pruned       | loss=0.6804 | accuracy=83.72%
neuron_pruned        | loss=0.3835 | accuracy=90.70%
channel_pruned       | loss=0.4434 | accuracy=93.02%
WARNING:tensorflow:5 out of the last 2040 calls to <function TensorFlowTrainer._make_function.<locals>.multi_step_on_iterator at 0x7ff07c4112d0> triggered tf.function retracing. Tracing is expensive and the excessive number of tracings could be due to (1) creating @tf.function repeatedly in a loop, (2) passing tensors with different shapes, (3) passing Python objects instead of tensors. For (1), please define your @tf.function outside of the loop. For (2), @tf.function has reduce_retracing=True option that can avoid unnecessary retracing. For (3), please refer to https://www.tensorflow.org/guide/function#controlling_retracing and https://www.tensorflow.org/api_docs/python/tf/function for  more details.
combined_pruned      | loss=0.4834 | accuracy=88.37%

--- Test set evaluation for Baseline ---
Test loss:     0.3030
Test accuracy: 93.02 %
2/2 ━━━━━━━━━━━━━━━━━━━━ 0s 65ms/step

Confusion Matrix for Baseline: 
[[11  0  1  0]
 [ 0 10  0  0]
 [ 0  0 10  0]
 [ 1  1  0  9]]
2/2 ━━━━━━━━━━━━━━━━━━━━ 0s 71ms/step

Confusion Matrix for Synapse Pruned: 
[[10  0  2  0]
 [ 0 10  0  0]
 [ 0  0 10  0]
 [ 4  1  0  6]]
WARNING:tensorflow:5 out of the last 5 calls to <function TensorFlowTrainer.make_predict_function.<locals>.one_step_on_data_distributed at 0x7ff07c489a20> triggered tf.function retracing. Tracing is expensive and the excessive number of tracings could be due to (1) creating @tf.function repeatedly in a loop, (2) passing tensors with different shapes, (3) passing Python objects instead of tensors. For (1), please define your @tf.function outside of the loop. For (2), @tf.function has reduce_retracing=True option that can avoid unnecessary retracing. For (3), please refer to https://www.tensorflow.org/guide/function#controlling_retracing and https://www.tensorflow.org/api_docs/python/tf/function for  more details.
1/2 ━━━━━━━━━━━━━━━━━━━━ 0s 68ms/stepWARNING:tensorflow:6 out of the last 6 calls to <function TensorFlowTrainer.make_predict_function.<locals>.one_step_on_data_distributed at 0x7ff07c489a20> triggered tf.function retracing. Tracing is expensive and the excessive number of tracings could be due to (1) creating @tf.function repeatedly in a loop, (2) passing tensors with different shapes, (3) passing Python objects instead of tensors. For (1), please define your @tf.function outside of the loop. For (2), @tf.function has reduce_retracing=True option that can avoid unnecessary retracing. For (3), please refer to https://www.tensorflow.org/guide/function#controlling_retracing and https://www.tensorflow.org/api_docs/python/tf/function for  more details.
2/2 ━━━━━━━━━━━━━━━━━━━━ 0s 73ms/step

Confusion Matrix for Neuron Pruned: 
[[10  0  2  0]
 [ 0 10  0  0]
 [ 0  0 10  0]
 [ 1  1  0  9]]
2/2 ━━━━━━━━━━━━━━━━━━━━ 0s 72ms/step

Confusion Matrix for Channel Pruned: 
[[11  0  1  0]
 [ 0 10  0  0]
 [ 0  0 10  0]
 [ 1  1  0  9]]
2/2 ━━━━━━━━━━━━━━━━━━━━ 0s 67ms/step

Confusion Matrix for Combined Pruned: 
[[10  1  1  0]
 [ 0 10  0  0]
 [ 0  0 10  0]
 [ 1  2  0  8]]

--- TFLite export ---
Saved artifact at 'artifacts/baseline_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140672133975376: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131768816: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131775152: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131773920: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131771104: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131774096: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131775680: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131973712: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131975296: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131975824: TensorSpec(shape=(), dtype=tf.resource, name=None)
WARNING: All log messages before absl::InitializeLog() is called are written to STDERR
W0000 00:00:1780443037.665783   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443037.665860   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:37.669195: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/baseline_saved_model
2026-06-02 23:30:37.672543: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:37.672589: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/baseline_saved_model
2026-06-02 23:30:37.682563: I tensorflow/compiler/mlir/mlir_graph_optimization_pass.cc:388] MLIR V1 optimization pass is not enabled
2026-06-02 23:30:37.683478: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:37.735838: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/baseline_saved_model
2026-06-02 23:30:37.743859: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 74671 microseconds.
2026-06-02 23:30:38.163909: I tensorflow/compiler/mlir/tensorflow/utils/dump_mlir_util.cc:268] disabling MLIR crash reproducer, set env var `MLIR_CRASH_REPRODUCER_DIRECTORY` to enable.

TFLite model -> artifacts/baseline.tflite (99.6 KB)

Finished! Baseline artifact written to: artifacts/baseline.tflite
Saved artifact at 'artifacts/synapse_pruned_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140671526502816: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140671526514080: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140671526516896: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140671526504752: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140671526510912: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857005888: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857004480: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857006064: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857003776: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857007648: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443039.060581   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443039.060660   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:39.063427: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/synapse_pruned_saved_model
2026-06-02 23:30:39.066405: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:39.066430: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/synapse_pruned_saved_model
2026-06-02 23:30:39.073348: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:39.110961: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/synapse_pruned_saved_model
2026-06-02 23:30:39.118941: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 55519 microseconds.

TFLite model -> artifacts/synapse_pruned.tflite (99.6 KB)

Finished! Synapse pruned artifact written to: artifacts/synapse_pruned.tflite
Saved artifact at 'artifacts/neuron_pruned_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140670857072832: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857077584: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857083920: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857185760: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857187696: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857186112: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857189280: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857186464: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857185936: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857189456: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443039.596487   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443039.596540   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:39.599455: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/neuron_pruned_saved_model
2026-06-02 23:30:39.603181: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:39.603211: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/neuron_pruned_saved_model
2026-06-02 23:30:39.611751: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:39.649951: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/neuron_pruned_saved_model
2026-06-02 23:30:39.658316: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 58868 microseconds.

TFLite model -> artifacts/neuron_pruned.tflite (99.6 KB)

Finished! Neuron pruned artifact written to: artifacts/neuron_pruned.tflite
Saved artifact at 'artifacts/channel_pruned_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140670857269792: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857276128: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670857268560: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853433824: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853437696: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853436112: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853439280: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853434704: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853435936: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853439456: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443040.177577   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443040.177627   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:40.180631: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/channel_pruned_saved_model
2026-06-02 23:30:40.184502: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:40.184549: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/channel_pruned_saved_model
2026-06-02 23:30:40.193025: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:40.233270: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/channel_pruned_saved_model
2026-06-02 23:30:40.241847: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 61224 microseconds.

TFLite model -> artifacts/channel_pruned.tflite (99.6 KB)

Finished! Channel pruned artifact written to: artifacts/channel_pruned.tflite
Saved artifact at 'artifacts/combined_pruned_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140670853776304: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853789680: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853777360: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853830912: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853834784: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853833200: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853836368: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853831792: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853833024: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853836544: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443040.742135   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443040.742201   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:40.744982: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/combined_pruned_saved_model
2026-06-02 23:30:40.747951: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:40.747995: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/combined_pruned_saved_model
2026-06-02 23:30:40.755290: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:40.796971: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/combined_pruned_saved_model
2026-06-02 23:30:40.805142: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 60171 microseconds.

TFLite model -> artifacts/combined_pruned.tflite (99.6 KB)

Finished! Combined pruned artifact written to: artifacts/combined_pruned.tflite
Saved artifact at 'artifacts/baseline_int8_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140672133975376: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131768816: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131775152: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131773920: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131771104: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131774096: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131775680: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131973712: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131975296: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140672131975824: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443041.312103   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443041.312143   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:41.314663: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/baseline_int8_saved_model
2026-06-02 23:30:41.317348: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:41.317391: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/baseline_int8_saved_model
2026-06-02 23:30:41.325006: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:41.367201: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/baseline_int8_saved_model
2026-06-02 23:30:41.375737: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 61080 microseconds.
fully_quantize: 0, inference_type: 6, input_inference_type: INT8, output_inference_type: INT8

TFLite model -> artifacts/baseline_int8.tflite (35.0 KB)

Finished! Baseline int8 artifact written to: artifacts/baseline_int8.tflite
Saved artifact at 'artifacts/combined_pruned_int8_saved_model'. The following endpoints are available:

* Endpoint 'serve'
  args_0 (POSITIONAL_ONLY): TensorSpec(shape=(None, 150, 9), dtype=tf.float32, name='imu_input')
Output Type:
  TensorSpec(shape=(None, 4), dtype=tf.float32, name=None)
Captures:
  140670853776304: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853789680: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853777360: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853830912: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853834784: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853833200: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853836368: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853831792: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853833024: TensorSpec(shape=(), dtype=tf.resource, name=None)
  140670853836544: TensorSpec(shape=(), dtype=tf.resource, name=None)
W0000 00:00:1780443042.316503   20176 tf_tfl_flatbuffer_helpers.cc:390] Ignored output_format.
W0000 00:00:1780443042.316564   20176 tf_tfl_flatbuffer_helpers.cc:393] Ignored drop_control_dependency.
2026-06-02 23:30:42.320113: I tensorflow/cc/saved_model/reader.cc:83] Reading SavedModel from: artifacts/combined_pruned_int8_saved_model
2026-06-02 23:30:42.322988: I tensorflow/cc/saved_model/reader.cc:51] Reading meta graph with tags { serve }
2026-06-02 23:30:42.323033: I tensorflow/cc/saved_model/reader.cc:146] Reading SavedModel debug info (if present) from: artifacts/combined_pruned_int8_saved_model
2026-06-02 23:30:42.331209: I tensorflow/cc/saved_model/loader.cc:234] Restoring SavedModel bundle.
2026-06-02 23:30:42.369446: I tensorflow/cc/saved_model/loader.cc:218] Running initialization op on SavedModel bundle at path: artifacts/combined_pruned_int8_saved_model
2026-06-02 23:30:42.378234: I tensorflow/cc/saved_model/loader.cc:317] SavedModel load for tags { serve }; Status: success: OK. Took 58124 microseconds.
fully_quantize: 0, inference_type: 6, input_inference_type: INT8, output_inference_type: INT8

TFLite model -> artifacts/combined_pruned_int8.tflite (35.0 KB)

Finished! Combined pruned int8 artifact written to: artifacts/combined_pruned_int8.tflite
Saved metrics: artifacts/model_metrics.csv
```
